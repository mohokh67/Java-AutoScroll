/**
 * 
 * @author moho
 *An interface to work with different events in different files(classes)
 */
public interface StringListener {
	public void textEmitter(String text);
	public void clear();
}
